<#
  Session Title: Azure Automation Runbooks in Practice
  Presenter: Mike Pfeiffer
#>

<#
Create an Azure Automation account
https://docs.microsoft.com/en-us/azure/automation/automation-quickstart-create-account
#>

<#
Import Az Modules into Azure Automation Account
 - Az.Accounts
 - Az.Automation
 - Az.Compute
 - Az.Resources
#>

<#
Az module support in Azure Automation
https://docs.microsoft.com/en-us/azure/automation/az-modules
#>

<#
You can store your own service principal creds and 
variables in the shared resources section of the 
automation account.
#>

<#
Create an Azure Automation runbook
https://docs.microsoft.com/en-us/azure/automation/automation-quickstart-create-runbook
#>

<#
Start/Stop VMs during off-hours solution in Azure Automation
https://docs.microsoft.com/en-us/azure/automation/automation-solution-vm-management
#>

<#
Deploy a Windows Hybrid Runbook Worker
https://docs.microsoft.com/en-us/azure/automation/automation-windows-hrw-install
#>

<#
Running PowerShell scripts as WebJobs
https://docs.microsoft.com/en-us/azure/app-service/webjobs-create
#>