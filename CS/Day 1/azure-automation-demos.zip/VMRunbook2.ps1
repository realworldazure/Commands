param
(
    [Parameter (Mandatory = $false)]
    [object] $WebhookData
)

#Get service principal details from shared resources
$cred = Get-AutomationPSCredential -Name 'SPCreds'
$tenantId = Get-AutomationVariable -Name 'TenantId'

#Auth with service principal
Connect-AzAccount -ServicePrincipal -Credential $cred -Tenant $tenantId

$vms = (ConvertFrom-Json -InputObject $WebhookData.RequestBody)

Import-Module Az.Compute

foreach($vm in $vms) {
    Stop-AzVM -Name $vm.Name -ResourceGroup $vm.ResourceGroup -Force
}

<#
Invoking the runbook
#>

$uri = "https://s4events.azure-automation.net/webhooks?token=1xc1iDzrkLc7Wqot341GzameBhYavv0msLwkQQo%2bB88%3d"

$vms  = @(
            @{ Name="web1";ResourceGroup="webservers"},
            @{ Name="web2";ResourceGroup="webservers"}
        )

$body = ConvertTo-Json -InputObject $vms
$header = @{ message="Started by Mike Pfeiffer"}

Invoke-WebRequest -Method Post -Uri $uri -Body $body -Headers $header

